# Component Life Cycle

- Mounting Phase
  - constructor()
  - render()
  - componentDidMount()
- Updating Phase
  - render()
- Unmounting phase
  - componentWillUnmount()
- Behind the scenes
  - Virtual DOM
