# Color-Palette
![color-palette-output](https://user-images.githubusercontent.com/81244698/140067974-e6af0980-b995-4fc9-852f-4ac19877aa32.png)
