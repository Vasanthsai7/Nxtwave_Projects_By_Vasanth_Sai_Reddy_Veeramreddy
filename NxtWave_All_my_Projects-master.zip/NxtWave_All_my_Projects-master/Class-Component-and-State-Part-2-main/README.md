# Class Component and State Part 2

- Searchable Users List
  - Searching User
  - Deleting User
- setState() 
  - Object Syntax
- Components
  - Passing Callbacks

![Screenshot from 2021-10-14 11-29-23](https://user-images.githubusercontent.com/81244698/137260401-70c333d4-272c-4743-b59a-c3cd7fe1700e.png)
