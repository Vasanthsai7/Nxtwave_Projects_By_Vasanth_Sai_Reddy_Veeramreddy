import Counter from './components/Counter'

import './App.css'

const App = () => <Counter />

export default App
