import CoinToss from './components/CoinToss'

import './App.css'

const App = () => <CoinToss />

export default App
