# Counter
![counter-op](https://user-images.githubusercontent.com/81244698/133797964-9568a2f5-a46e-45f7-b2c4-8305a29bf99f.gif)
