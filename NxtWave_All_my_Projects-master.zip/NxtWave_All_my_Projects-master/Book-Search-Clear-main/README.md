# Book-Search-Clear
![book_search_output](https://user-images.githubusercontent.com/81244698/132281702-017ee36e-6786-4942-b38e-464f16b67636.gif)
